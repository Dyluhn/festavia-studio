# Festavia Track

A modular soffit track for Philips Hue Festavia permanent outdoor puck lights.

1. Open the [configuration guide](docs/Festavia-Configuration-Guide.pdf) and measure a straight run from cap face to cap face. A [phone-friendly version](docs/Festavia-Configuration-Guide.html) opens after extracting this ZIP.
2. Open the [offline workbench](workbench/index.html), or load one of the SCAD files below in [MakerWorld Parametric Model Maker](https://makerworld.com/en/makerlab/parametricModelMaker) under **Creator Portal → Open SCAD File**. Choose **Generate** after changing a value.
3. Follow the [assembly picture manual](docs/Festavia-Assembly-Manual.pdf) at the bench. The [browser edition](docs/Festavia-Assembly-Manual.html) includes the same diagrams.

| File | Use it for |
|---|---|
| [Festavia-Run.scad](Festavia-Run.scad) | Plan a complete straight run. Set your length, pitch, bed and cable exits. Download every batch shown in Assemble View. |
| [Festavia-Section.scad](Festavia-Section.scad) | Make a replacement section or a fit coupon. |
| [Festavia-Accessories.scad](Festavia-Accessories.scad) | Optional power-supply cradle, cable slack box, matching v2 covers, siding shims and cable clips. Print one matching base and cover per box. Individual STLs and fasteners are in the [accessories folder](accessories/README.md). |
| [Festavia-15ft-P1S.3mf](Festavia-15ft-P1S.3mf) | A fixed 15 ft example on 12 plates. Set your filament, check supports and slice locally. |

The workbench's **Boxes & clips** tab previews and downloads accessories independently of a track run. The historical ZIP verifier under Explore examples accepts the original desktop example archive. This MakerWorld download can be used directly after extraction.

![Installed straight run](assets/installed-run.jpg)
