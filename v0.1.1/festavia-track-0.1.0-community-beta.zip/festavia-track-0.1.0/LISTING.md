# Modular track for Festavia permanent outdoor lights

**Parametric community beta — fit test first.**

Make a straight soffit track for your own run length, light spacing and printer
bed. Compatible with the measured Philips Hue Festavia permanent outdoor puck
interface. No manufacturer logos or endorsement are claimed.

The established A0 design uses two tongue/socket rails, two splice bars and two
pins per joint. The light holder's strengthened lock tabs, turn-to-lock ring,
stop pin and sliding-lever soffit bracket are retained from the installed design.
Optional thicker channel shells trade more material for greater local bending
rigidity. They are CAD options, not a tested load rating.

Included:

- One self-contained OpenSCAD Customizer file and desktop parameter presets.
- A complete local exporter and guided launchers for Windows/macOS/Linux.
- Editable examples for 180 mm, 256 mm and larger beds, inches and millimetres.
- Numbered pieces, packed STL/3MF plates, a BOM, light/bracket diagram and pin schedule.
- Small joint and single-nozzle test plates, plus assembly and customization guides.

Set your run and bed size. The planner keeps all the holders that fit and changes
the section lengths automatically. You can preserve measured first-light and
bracket positions, subject to the mechanical clearances. Separate supported runs
handle corners and roof changes; a structural corner elbow is not included.

Use PETG for the reference fit. Print the coupons first; check ring retention,
pin fit, lever latching and breakaway-rib removal on your printer before printing
the whole run. Alternative fit/shell/material combinations are not physically
qualified. No new parts were printed during this software/CAD release validation.

Suggested gallery, all CAD illustrations rather than installation photographs:

1. `assets/01_hero_installed.png` — reference track under a soffit, with stand-in pucks and cable.
2. `assets/02_light_holder_ring.png` — holder, ring and stop pin.
3. `assets/03_joint_exploded.png` — replaceable splice bars and pins.
4. `assets/04_bracket_lever_lift.png` — bracket and lever assembly.
5. `assets/06_print_plate_256.png` — reference track plate.

For MakerWorld upload, use the single `.scad` file. Exact cloud runtime and
parameter-set import are unverified; the tested desktop OpenSCAD workflow remains
available. Distribution is prepared locally; this package does not create a live
listing or upload files on your behalf.
