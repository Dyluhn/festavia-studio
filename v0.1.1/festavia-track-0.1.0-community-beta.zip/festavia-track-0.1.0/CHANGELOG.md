# Changes

## 0.1.0 — 2026-11-18

- Completed the community distribution around the November 11 parametric port.
- Kept installed A0 joint, revised puck holder, bracket and lever interfaces.
- Added reinforced/custom shells and measured CAD section-property comparisons.
- Fixed short metric cap ends and end-piece seam/length accounting.
- Fixed exact inch/mm input boundaries and hardware tree-support spacing.
- Made zero spare percentage omit extras, and clarified per-part support needs.
- Added fixed first-light offsets and measured bracket-centre preservation.
- Added a joint coupon, portable guided exporter, named geometry 3MF objects,
  independent plan/BOM/plate checks and complete-kit integrity manifests.
- Added print, assembly, fit-report and community qualification documentation.

Physical fit and outdoor history remain separate from digital validation.
